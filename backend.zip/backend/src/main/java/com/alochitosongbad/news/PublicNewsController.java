package com.alochitosongbad.news;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/public/news")
public class PublicNewsController {

    private final NewsService newsService;

    public PublicNewsController(NewsService newsService) {
        this.newsService = newsService;
    }

    @GetMapping
    public Object getPublishedNews(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        return newsService.getPublishedNews(page, size);
    }

    @GetMapping("/{slug}")
    public ResponseEntity<NewsResponseDto> getPublishedNewsBySlug(@PathVariable String slug) {
        return newsService.getPublishedNewsBySlug(slug)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
