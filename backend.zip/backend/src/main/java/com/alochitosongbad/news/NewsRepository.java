package com.alochitosongbad.news;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NewsRepository extends JpaRepository<News, Long> {
    List<News> findByStatusOrderByIdDesc(String status);

    Page<News> findByStatus(String status, Pageable pageable);

    Optional<News> findBySlug(String slug);

    Optional<News> findBySlugAndStatus(String slug, String status);

    boolean existsBySlug(String slug);

    boolean existsBySlugAndIdNot(String slug, Long id);
}
