package com.alochitosongbad.news;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.alochitosongbad.category.Category;
import com.alochitosongbad.category.CategoryRepository;
import com.alochitosongbad.security.CurrentUserService;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class NewsService {

    private static final Set<String> ALLOWED_STATUSES = Set.of("draft", "review", "published", "archived");

    private final NewsRepository newsRepository;
    private final CategoryRepository categoryRepository;
    private final CurrentUserService currentUserService;

    public NewsService(
            NewsRepository newsRepository,
            CategoryRepository categoryRepository,
            CurrentUserService currentUserService) {
        this.newsRepository = newsRepository;
        this.categoryRepository = categoryRepository;
        this.currentUserService = currentUserService;
    }

    public Object getAllNews(Integer page, Integer size) {
        if (page != null || size != null) {
            return newsRepository.findAll(createPageRequest(page, size)).map(this::toResponseDto);
        }

        return newsRepository.findAll().stream().map(this::toResponseDto).toList();
    }

    public Optional<NewsResponseDto> getNewsById(Long id) {
        return newsRepository.findById(id).map(this::toResponseDto);
    }

    public Optional<NewsResponseDto> getNewsBySlug(String slug) {
        return newsRepository.findBySlug(slug).map(this::toResponseDto);
    }

    public NewsResponseDto createNews(NewsRequestDto request) {
        News news = toEntity(request);
        news.setId(null);
        news.setViewCount(0);
        news.setCreatedBy(currentUserService.username());
        prepareForSave(news);
        ensureCanCreateStatus(news.getStatus());
        setPublishedByIfNeeded(news);
        rejectDuplicateSlug(news.getSlug(), null);
        return toResponseDto(newsRepository.save(news));
    }

    public Optional<NewsResponseDto> updateNews(Long id, NewsRequestDto request) {
        return newsRepository.findById(id)
                .map(existing -> {
                    String previousStatus = existing.getStatus();
                    ensureCanEdit(existing);
                    copyEditableFields(existing, request);
                    existing.setUpdatedBy(currentUserService.username());
                    prepareForSave(existing);
                    ensureCanSaveStatus(existing.getStatus());
                    ensureAllowedStatusTransition(previousStatus, existing.getStatus());
                    setPublishedByIfNeeded(existing);
                    rejectDuplicateSlug(existing.getSlug(), existing.getId());
                    return toResponseDto(newsRepository.save(existing));
                });
    }

    public boolean deleteNews(Long id) {
        currentUserService.requireAdmin("delete news");

        if (!newsRepository.existsById(id)) {
            return false;
        }

        newsRepository.deleteById(id);
        return true;
    }

    public Optional<NewsResponseDto> updateNewsStatus(Long id, String statusValue) {
        String status = normalizeStatus(statusValue);
        ensureCanSaveStatus(status);

        return newsRepository.findById(id)
                .map(news -> {
                    ensureCanChangeStatus(news, status);
                    news.setStatus(status);
                    news.setUpdatedBy(currentUserService.username());
                    if ("published".equals(status) && isBlank(news.getPublishDate())) {
                        news.setPublishDate(isBlank(news.getScheduledAt()) ? nowIso() : news.getScheduledAt());
                    }
                    setPublishedByIfNeeded(news);
                    return toResponseDto(newsRepository.save(news));
                });
    }

    public Optional<NewsResponseDto> incrementViewCount(Long id) {
        return newsRepository.findById(id)
                .map(news -> {
                    news.setViewCount(news.getViewCount() + 1);
                    return toResponseDto(newsRepository.save(news));
                });
    }

    public Object getPublishedNews(Integer page, Integer size) {
        List<News> publishedNews = visiblePublishedNews();

        if (page != null || size != null) {
            PageRequest pageRequest = createPublicPageRequest(page, size);
            int start = Math.min((int) pageRequest.getOffset(), publishedNews.size());
            int end = Math.min(start + pageRequest.getPageSize(), publishedNews.size());

            return new PageImpl<>(
                    publishedNews.subList(start, end).stream().map(this::toResponseDto).toList(),
                    pageRequest,
                    publishedNews.size());
        }

        return publishedNews.stream().map(this::toResponseDto).toList();
    }

    public Optional<NewsResponseDto> getPublishedNewsBySlug(String slug) {
        return newsRepository.findBySlugAndStatus(slug, "published")
                .filter(this::isPubliclyVisible)
                .map(this::toResponseDto);
    }

    private News toEntity(NewsRequestDto request) {
        News news = new News();
        copyEditableFields(news, request);
        return news;
    }

    private NewsResponseDto toResponseDto(News news) {
        NewsResponseDto response = new NewsResponseDto();
        response.setId(news.getId());
        response.setTitle(news.getTitle());
        response.setSubtitle(news.getSubtitle());
        response.setContent(news.getContent());
        response.setImageUrl(news.getImageUrl());
        response.setImageCaption(news.getImageCaption());
        response.setImageSource(news.getImageSource());
        response.setImageAlt(news.getImageAlt());
        response.setStatus(news.getStatus());
        response.setCategory(categoryLabel(news.getCategory()));
        response.setReporterName(news.getReporterName());
        response.setSource(news.getSource());
        response.setTags(news.getTags());
        response.setSeoTitle(news.getSeoTitle());
        response.setSeoDescription(news.getSeoDescription());
        response.setSlug(news.getSlug());
        response.setBreaking(news.isBreaking());
        response.setFeatured(news.isFeatured());
        response.setScheduledAt(news.getScheduledAt());
        response.setPublishDate(news.getPublishDate());
        response.setViewCount(news.getViewCount());
        response.setCreatedAt(news.getCreatedAt());
        response.setUpdatedAt(news.getUpdatedAt());
        return response;
    }

    private void copyEditableFields(News target, NewsRequestDto source) {
        target.setTitle(source.getTitle());
        target.setSubtitle(source.getSubtitle());
        target.setContent(source.getContent());
        target.setImageUrl(source.getImageUrl());
        target.setImageCaption(source.getImageCaption());
        target.setImageSource(source.getImageSource());
        target.setImageAlt(source.getImageAlt());
        target.setStatus(source.getStatus());
        target.setCategory(resolveCategory(source.getCategory()));
        target.setReporterName(source.getReporterName());
        target.setSource(source.getSource());
        target.setTags(source.getTags());
        target.setSeoTitle(source.getSeoTitle());
        target.setSeoDescription(source.getSeoDescription());
        target.setSlug(source.getSlug());
        target.setBreaking(source.isBreaking());
        target.setFeatured(source.isFeatured());
        target.setScheduledAt(source.getScheduledAt());
        target.setPublishDate(source.getPublishDate());
    }

    private void prepareForSave(News news) {
        requireText(news.getTitle(), "title is required");
        requireText(news.getSlug(), "slug is required");
        requireCategory(news.getCategory());
        news.setTitle(news.getTitle().trim());
        news.setSlug(news.getSlug().trim());
        news.setStatus(normalizeStatus(news.getStatus()));
        news.setScheduledAt(normalizeDateTime(news.getScheduledAt(), "scheduledAt"));
        news.setPublishDate(normalizeDateTime(news.getPublishDate(), "publishDate"));
        if (isBlank(news.getPublishDate()) && !isBlank(news.getScheduledAt())) {
            news.setPublishDate(news.getScheduledAt());
        }
        if ("published".equals(news.getStatus()) && isBlank(news.getPublishDate())) {
            news.setPublishDate(nowIso());
        }
        if (news.getViewCount() < 0) {
            news.setViewCount(0);
        }
    }

    private void rejectDuplicateSlug(String slug, Long currentNewsId) {
        boolean duplicate = currentNewsId == null
                ? newsRepository.existsBySlug(slug)
                : newsRepository.existsBySlugAndIdNot(slug, currentNewsId);

        if (duplicate) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "slug already exists");
        }
    }

    private String normalizeStatus(String status) {
        if (isBlank(status)) {
            return "draft";
        }

        String normalized = status.trim().toLowerCase();
        if (!ALLOWED_STATUSES.contains(normalized)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "status must be draft, review, published, or archived");
        }

        return normalized;
    }

    private void ensureCanSaveStatus(String status) {
        if ("published".equals(status)) {
            if (!currentUserService.canPublish()) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "reporter cannot publish news");
            }
            return;
        }

        if ("archived".equals(status) && currentUserService.isReporter()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "reporter cannot archive news");
        }
    }

    private void ensureCanCreateStatus(String status) {
        ensureCanSaveStatus(status);

        if ("published".equals(status) && !currentUserService.isAdmin()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "news must be sent to review before publishing");
        }

        if ("archived".equals(status)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "new news cannot be archived");
        }
    }

    private void ensureCanChangeStatus(News news, String nextStatus) {
        String currentStatus = news.getStatus();

        if ("archived".equals(nextStatus)) {
            currentUserService.requireEditorOrAdmin("archive or restore news");
            return;
        }

        if ("archived".equals(currentStatus)) {
            currentUserService.requireEditorOrAdmin("archive or restore news");
            if ("published".equals(nextStatus) && !currentUserService.isAdmin()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "restore archived news before publishing");
            }
            return;
        }

        ensureCanEdit(news);
        ensureCanSaveStatus(nextStatus);
        ensureAllowedStatusTransition(currentStatus, nextStatus);
    }

    private void ensureAllowedStatusTransition(String previousStatus, String nextStatus) {
        if (!"published".equals(nextStatus) || "published".equals(previousStatus) || currentUserService.isAdmin()) {
            return;
        }

        if (!"review".equals(previousStatus)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "news must be reviewed before publishing");
        }
    }

    private void ensureCanEdit(News news) {
        if (currentUserService.isAdmin()) {
            return;
        }

        if (currentUserService.isEditor()) {
            if ("archived".equals(news.getStatus())) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "editor cannot edit archived news");
            }
            return;
        }

        if (currentUserService.isReporter() && currentUserService.username().equals(news.getCreatedBy())) {
            return;
        }

        throw new ResponseStatusException(HttpStatus.FORBIDDEN, "reporter can edit only own news");
    }

    private void setPublishedByIfNeeded(News news) {
        if ("published".equals(news.getStatus()) && isBlank(news.getPublishedBy())) {
            news.setPublishedBy(currentUserService.username());
        }
    }

    private String normalizeDateTime(String value, String fieldName) {
        if (isBlank(value)) {
            return "";
        }

        String normalized = value.trim().replace(' ', 'T');
        try {
            return LocalDateTime.parse(normalized).toString();
        } catch (DateTimeParseException exception) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, fieldName + " must be an ISO datetime");
        }
    }

    private String nowIso() {
        return LocalDateTime.now().toString();
    }

    private List<News> visiblePublishedNews() {
        return newsRepository.findByStatusOrderByIdDesc("published").stream()
                .filter(this::isPubliclyVisible)
                .sorted((left, right) -> {
                    int dateComparison = publicPublishDate(right).compareTo(publicPublishDate(left));
                    if (dateComparison != 0) {
                        return dateComparison;
                    }

                    return Long.compare(idValue(right), idValue(left));
                })
                .toList();
    }

    private boolean isPubliclyVisible(News news) {
        if (!"published".equals(news.getStatus())) {
            return false;
        }

        return !publicPublishDate(news).isAfter(LocalDateTime.now());
    }

    private LocalDateTime publicPublishDate(News news) {
        LocalDateTime parsedPublishDate = parseDateTimeOrNull(news.getPublishDate());
        if (parsedPublishDate != null) {
            return parsedPublishDate;
        }

        LocalDateTime parsedScheduledAt = parseDateTimeOrNull(news.getScheduledAt());
        if (parsedScheduledAt != null) {
            return parsedScheduledAt;
        }

        return news.getCreatedAt() == null ? LocalDateTime.MIN : news.getCreatedAt();
    }

    private LocalDateTime parseDateTimeOrNull(String value) {
        if (isBlank(value)) {
            return null;
        }

        try {
            return LocalDateTime.parse(value.trim().replace(' ', 'T'));
        } catch (DateTimeParseException exception) {
            return null;
        }
    }

    private long idValue(News news) {
        return news.getId() == null ? 0 : news.getId();
    }

    private PageRequest createPageRequest(Integer page, Integer size) {
        int safePage = page == null ? 0 : Math.max(0, page);
        int safeSize = size == null ? 20 : Math.min(Math.max(1, size), 100);
        return PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "id"));
    }

    private PageRequest createPublicPageRequest(Integer page, Integer size) {
        int safePage = page == null ? 0 : Math.max(0, page);
        int safeSize = size == null ? 20 : Math.min(Math.max(1, size), 100);
        return PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "publishDate").and(Sort.by(Sort.Direction.DESC, "id")));
    }

    private void requireText(String value, String message) {
        if (isBlank(value)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
        }
    }

    private void requireCategory(Category category) {
        if (category == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "category does not exist");
        }
    }

    private Category resolveCategory(String categoryValue) {
        requireText(categoryValue, "category is required");
        String value = categoryValue.trim();

        return categoryRepository.findBySlug(value)
                .or(() -> categoryRepository.findBySlug(value.toLowerCase()))
                .or(() -> categoryRepository.findByNameIgnoreCase(value))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "category does not exist"));
    }

    private String categoryLabel(Category category) {
        if (category == null) {
            return "";
        }

        return category.getName() == null || category.getName().isBlank() ? category.getSlug() : category.getName();
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
