package com.alochitosongbad.media;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.alochitosongbad.security.CurrentUserService;

import jakarta.annotation.PostConstruct;

import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Service
public class MediaAssetService {

    private static final Logger log = LoggerFactory.getLogger(MediaAssetService.class);

    private final MediaAssetRepository mediaAssetRepository;
    private final CurrentUserService currentUserService;
    private final Path uploadRoot;

    public MediaAssetService(
            MediaAssetRepository mediaAssetRepository,
            CurrentUserService currentUserService,
            MediaStorageProperties mediaStorageProperties) {
        this.mediaAssetRepository = mediaAssetRepository;
        this.currentUserService = currentUserService;
        this.uploadRoot = mediaStorageProperties.uploadRoot();
    }

    @PostConstruct
    void createUploadDirectory() throws IOException {
        Files.createDirectories(uploadRoot);
        log.info("Media upload directory ready at {}", uploadRoot);
    }

    public List<MediaAsset> getAll() {
        currentUserService.requireEditorOrAdmin("view media");
        return mediaAssetRepository.findAllByOrderByCreatedAtDesc();
    }

    public MediaAsset upload(MultipartFile file, String title) {
        String username = currentUserService.username();
        validateUpload(file);

        String originalFileName = safeFileName(file.getOriginalFilename());
        String displayName = normalizeDisplayName(title, originalFileName);
        String storedFileName = UUID.randomUUID() + "-" + originalFileName;
        Path destination = uploadRoot.resolve(storedFileName).normalize();

        if (!destination.startsWith(uploadRoot)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "invalid file path");
        }

        log.info(
                "Media upload request: user={}, fileName={}, contentType={}, size={}, destination={}",
                username,
                originalFileName,
                file.getContentType(),
                file.getSize(),
                destination);

        try {
            file.transferTo(destination);
        } catch (IOException exception) {
            log.warn("Media upload failed at {}", destination, exception);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "could not store file");
        }

        MediaAsset mediaAsset = new MediaAsset();
        mediaAsset.setFileName(displayName);
        mediaAsset.setFileUrl(fileUrl(storedFileName));
        mediaAsset.setContentType(file.getContentType());
        mediaAsset.setSize(file.getSize());
        mediaAsset.setUploadedBy(username);
        MediaAsset savedAsset = mediaAssetRepository.save(mediaAsset);
        log.info("Media upload saved: id={}, fileUrl={}", savedAsset.getId(), savedAsset.getFileUrl());
        return savedAsset;
    }

    public boolean delete(Long id) {
        currentUserService.requireEditorOrAdmin("delete media");
        Optional<MediaAsset> mediaAsset = mediaAssetRepository.findById(id);

        if (mediaAsset.isEmpty()) {
            return false;
        }

        deleteStoredFile(mediaAsset.get());
        mediaAssetRepository.deleteById(id);
        return true;
    }

    private void validateUpload(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "file is required");
        }

        String contentType = file.getContentType();
        if (contentType == null || !contentType.toLowerCase().startsWith("image/")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "only image files are allowed");
        }
    }

    private String normalizeDisplayName(String title, String fallback) {
        if (title == null || title.isBlank()) {
            return fallback;
        }

        return title.trim();
    }

    private String safeFileName(String fileName) {
        String fallback = "image";
        String cleanName = fileName == null || fileName.isBlank() ? fallback : Path.of(fileName).getFileName().toString();
        cleanName = cleanName.replaceAll("[^A-Za-z0-9._-]", "-");
        return cleanName.isBlank() ? fallback : cleanName;
    }

    private String fileUrl(String storedFileName) {
        return ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/uploads/")
                .path(storedFileName)
                .toUriString();
    }

    private void deleteStoredFile(MediaAsset mediaAsset) {
        String fileUrl = mediaAsset.getFileUrl();
        String storedFileName = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
        Path target = uploadRoot.resolve(storedFileName).normalize();

        if (!target.startsWith(uploadRoot)) {
            return;
        }

        try {
            Files.deleteIfExists(target);
        } catch (IOException exception) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "could not delete file");
        }
    }
}
