import { Routes } from '@angular/router';
import { authGuard, roleGuard } from './auth/auth.guard';
import { unsavedChangesGuard } from './admin/guards/unsaved-changes.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./auth/login.component').then((m) => m.LoginComponent)
  },
  {
    path: '',
    loadComponent: () => import('./public/pages/home/home.component').then((m) => m.HomeComponent)
  },
  {
    path: 'news',
    loadComponent: () => import('./public/pages/news-list/news-list.component').then((m) => m.NewsListComponent)
  },
  {
    path: 'news/:slug',
    loadComponent: () => import('./public/pages/news-detail/news-detail.component').then((m) => m.NewsDetailComponent)
  },
  {
    path: 'category/:name',
    loadComponent: () => import('./public/pages/category/category.component').then((m) => m.CategoryComponent)
  },
  {
    path: 'admin',
    canActivate: [authGuard],
    loadComponent: () => import('./admin/layout/admin-layout.component').then((m) => m.AdminLayoutComponent),
    children: [
      {
        path: '',
        pathMatch: 'full',
        loadComponent: () => import('./admin/pages/dashboard/dashboard.component').then((m) => m.DashboardComponent)
      },
      {
        path: 'news',
        data: { roles: ['admin', 'editor', 'reporter'] },
        loadComponent: () => import('./admin/pages/news-management/news-management.component').then((m) => m.NewsManagementComponent)
      },
      {
        path: 'news/create',
        data: { roles: ['admin', 'editor', 'reporter'] },
        canDeactivate: [unsavedChangesGuard],
        loadComponent: () => import('./admin/pages/news-form/news-form.component').then((m) => m.NewsFormComponent)
      },
      {
        path: 'news/edit/:id',
        data: { roles: ['admin', 'editor', 'reporter'] },
        canDeactivate: [unsavedChangesGuard],
        loadComponent: () => import('./admin/pages/news-form/news-form.component').then((m) => m.NewsFormComponent)
      },
      {
        path: 'categories',
        data: { roles: ['admin', 'editor'] },
        loadComponent: () => import('./admin/pages/categories/categories.component').then((m) => m.CategoriesComponent)
      },
      {
        path: 'media',
        data: { roles: ['admin', 'editor'] },
        loadComponent: () => import('./admin/pages/media-library/media-library.component').then((m) => m.MediaLibraryComponent)
      },
      {
        path: 'comments',
        data: { roles: ['admin', 'editor'] },
        loadComponent: () => import('./admin/pages/comments/comments.component').then((m) => m.CommentsComponent)
      },
      {
        path: 'breaking-news',
        data: { roles: ['admin', 'editor'] },
        loadComponent: () => import('./admin/pages/breaking-news/breaking-news.component').then((m) => m.BreakingNewsComponent)
      },
      {
        path: 'team',
        data: { roles: ['admin'] },
        loadComponent: () => import('./admin/pages/team/team.component').then((m) => m.TeamComponent)
      },
      {
        path: 'homepage-customize',
        data: { roles: ['admin'] },
        loadComponent: () => import('./admin/pages/homepage-customize/homepage-customize.component').then((m) => m.HomepageCustomizeComponent)
      },
      {
        path: 'website-info',
        data: { roles: ['admin'] },
        loadComponent: () => import('./admin/pages/website-info/website-info.component').then((m) => m.WebsiteInfoComponent)
      }
    ],
    canActivateChild: [roleGuard]
  },
  {
    path: '**',
    loadComponent: () => import('./public/pages/not-found/not-found.component').then((m) => m.NotFoundComponent)
  }
];
