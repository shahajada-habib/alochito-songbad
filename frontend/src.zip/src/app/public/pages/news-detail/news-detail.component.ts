import { Component, HostListener, computed, effect, inject, signal } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { ToastService } from '../../../admin/services/toast.service';
import { News, NewsService } from '../../../admin/services/news.service';
import { formatNewsDate, formatViewCount, getReadingTime, stripHtml } from '../../../shared/news-format.util';

const NEWS_PREVIEW_STORAGE_KEY = 'alochito_news_preview';

type ArticleView = {
  id: number;
  title: string;
  category: string;
  summary: string;
  image: string;
  imageCaption: string;
  imageSource: string;
  imageAlt: string;
  slug: string;
  bylineLabel: string;
  reporter: string;
  publishedAt: string;
  readingTime: string;
  viewLabel: string;
  content: string;
  seoDescription: string;
  isPreview: boolean;
};

type RelatedArticle = {
  title: string;
  category: string;
  image: string;
  slug: string;
  time: string;
  readingTime: string;
  viewLabel: string;
};

@Component({
  selector: 'app-news-detail',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './news-detail.component.html',
  styleUrl: './news-detail.component.css'
})
export class NewsDetailComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly newsService = inject(NewsService);
  private readonly title = inject(Title);
  private readonly meta = inject(Meta);
  private readonly toast = inject(ToastService);
  private countedSlug = '';
  private lastScrolledSlug = '';
  private progressFrame: number | null = null;
  protected readonly isLoading = signal(true);
  protected readonly readingProgress = signal(0);

  protected readonly slug = toSignal(
    this.route.paramMap.pipe(map((params) => params.get('slug') ?? '')),
    { initialValue: '' }
  );

  protected readonly isPreviewRequest = toSignal(
    this.route.queryParamMap.pipe(map((params) => params.get('preview') === '1')),
    { initialValue: false }
  );

  protected readonly article = computed<ArticleView | null>(() => {
    const targetSlug = this.normalizeSlug(this.slug());
    if (!targetSlug) {
      return null;
    }

    if (this.isPreviewRequest()) {
      const previewNews = this.getPreviewNews(targetSlug);

      if (previewNews) {
        return this.mapArticle(previewNews, true);
      }
    }

    const match = this.newsService
      .getAll()
      .find((item) => this.newsService.isPubliclyVisible(item) && this.normalizeSlug(item.slug || item.title) === targetSlug);

    return match ? this.mapArticle(match) : null;
  });

  protected readonly relatedNews = computed<RelatedArticle[]>(() => {
    const current = this.article();
    if (!current) {
      return [];
    }

    return this.newsService
      .getAll()
      .filter((item) => this.newsService.isPubliclyVisible(item))
      .filter((item) => item.category === current.category)
      .filter((item) => this.normalizeSlug(item.slug || item.title) !== this.normalizeSlug(current.slug))
      .sort((left, right) => this.getSortValue(right) - this.getSortValue(left))
      .slice(0, 5)
      .map((item) => ({
        title: item.title,
        category: item.category,
        image: item.imageUrl || this.getPlaceholderImage(item.id),
        slug: this.cleanSlug(item.slug || item.title || `news-${item.id}`),
        time: formatNewsDate(item.publishDate || item.scheduledAt || item.createdAt, 'bn') || item.createdAt || '',
        readingTime: getReadingTime(item.content || item.subtitle || item.title, 'bn'),
        viewLabel: formatViewCount(item.viewCount ?? 0, 'bn')
      }));
  });

  protected readonly latestNews = computed<RelatedArticle[]>(() => {
    const current = this.article();
    if (!current) {
      return [];
    }

    const excluded = new Set<string>([current.slug, ...this.relatedNews().map((item) => item.slug)]);

    return this.buildEngagementCards({
      excluded,
      limit: 4,
      sortBy: 'latest'
    });
  });

  protected readonly trendingNews = computed<RelatedArticle[]>(() => {
    const current = this.article();
    if (!current) {
      return [];
    }

    const excluded = new Set<string>([
      current.slug,
      ...this.relatedNews().map((item) => item.slug),
      ...this.latestNews().map((item) => item.slug)
    ]);

    return this.buildEngagementCards({
      excluded,
      limit: 4,
      sortBy: 'trending'
    });
  });

  constructor() {
    setTimeout(() => this.isLoading.set(false), 850);
    this.scheduleReadingProgressUpdate();

    effect(() => {
      const currentSlug = this.slug();
      if (currentSlug && currentSlug !== this.lastScrolledSlug && typeof window !== 'undefined') {
        this.lastScrolledSlug = currentSlug;
        setTimeout(() => window.scrollTo({ top: 0, behavior: 'auto' }), 0);
      }

      if (this.newsService.news().length > 0) {
        this.isLoading.set(false);
      }

      const article = this.article();
      if (!article) {
        this.title.setTitle('News not found');
        this.meta.updateTag({ name: 'description', content: 'The requested news article could not be found.' });
        return;
      }

      this.title.setTitle(article.title);
      this.meta.updateTag({
        name: 'description',
        content: article.seoDescription || article.summary
      });

      if (!article.isPreview && this.countedSlug !== article.slug) {
        this.countedSlug = article.slug;
        this.newsService.incrementViewCount(article.id);
      }
    });
  }

  @HostListener('window:scroll')
  protected updateReadingProgress(): void {
    this.scheduleReadingProgressUpdate();
  }

  protected facebookShareUrl(article: ArticleView): string {
    return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(this.currentArticleUrl(article))}`;
  }

  protected twitterShareUrl(article: ArticleView): string {
    const url = encodeURIComponent(this.currentArticleUrl(article));
    const text = encodeURIComponent(article.title);

    return `https://twitter.com/intent/tweet?url=${url}&text=${text}`;
  }

  protected copyArticleLink(article: ArticleView): void {
    this.copyToClipboard(this.currentArticleUrl(article));
    this.toast.success('লিংক কপি হয়েছে');
  }

  private scheduleReadingProgressUpdate(): void {
    if (typeof window === 'undefined') {
      return;
    }

    if (this.progressFrame !== null) {
      return;
    }

    this.progressFrame = window.requestAnimationFrame(() => {
      this.progressFrame = null;
      const documentElement = document.documentElement;
      const scrollTop = window.scrollY || documentElement.scrollTop;
      const scrollableHeight = documentElement.scrollHeight - window.innerHeight;
      const progress = scrollableHeight > 0 ? (scrollTop / scrollableHeight) * 100 : 0;

      this.readingProgress.set(Math.min(100, Math.max(0, progress)));
    });
  }

  private mapArticle(news: News, isPreview = false): ArticleView {
    const summary = this.buildArticleSummary(news.subtitle || '', news.content || '');

    return {
      id: news.id,
      title: news.title,
      category: news.category,
      summary,
      image: news.imageUrl,
      imageCaption: news.imageCaption || '',
      imageSource: news.imageSource || '',
      imageAlt: news.imageAlt || '',
      slug: this.cleanSlug(news.slug || news.title || `news-${news.id}`),
      bylineLabel: news.reporterName ? 'প্রতিবেদক' : news.source ? 'ডেস্ক' : 'সংবাদ',
      reporter: news.reporterName || news.source || 'আলোচিত সংবাদ',
      publishedAt: formatNewsDate(news.publishDate || news.scheduledAt || news.createdAt, 'bn') || news.createdAt || '',
      readingTime: getReadingTime(news.content || news.subtitle || news.title, 'bn'),
      viewLabel: formatViewCount(news.viewCount ?? 0, 'bn'),
      content: news.content || '',
      seoDescription: news.seoDescription || news.subtitle || stripHtml(news.content) || news.title,
      isPreview
    };
  }

  private buildArticleSummary(subtitle: string, content: string): string {
    const normalizedSubtitle = this.normalizeText(this.stripArticleText(subtitle));
    if (!normalizedSubtitle) {
      return '';
    }

    if (normalizedSubtitle.length > 180) {
      return '';
    }

    if (this.isDuplicateSubtitle(subtitle, content)) {
      return '';
    }

    return subtitle.trim();
  }

  private isDuplicateSubtitle(subtitle: string, content: string): boolean {
    const normalizedSubtitle = this.normalizeText(this.stripArticleText(subtitle));
    const normalizedContent = this.normalizeText(this.stripArticleText(content));

    if (!normalizedSubtitle || !normalizedContent) {
      return false;
    }

    const previewLength = Math.min(Math.max(normalizedSubtitle.length, 120), 180);
    const contentPreview = normalizedContent.slice(0, previewLength);

    return contentPreview === normalizedSubtitle.slice(0, previewLength);
  }

  private stripArticleText(value: string): string {
    return stripHtml(value || '');
  }

  private normalizeText(value: string): string {
    return (value || '')
      .replace(/\s+/g, ' ')
      .replace(/\u00a0/g, ' ')
      .trim()
      .toLowerCase();
  }

  private getPreviewNews(targetSlug: string): News | null {
    if (typeof localStorage === 'undefined') {
      return null;
    }

    try {
      const rawPreview = localStorage.getItem(NEWS_PREVIEW_STORAGE_KEY);
      if (!rawPreview) {
        return null;
      }

      const preview = JSON.parse(rawPreview) as News;
      const previewSlug = this.normalizeSlug(preview.slug || preview.title || '');

      if (previewSlug !== targetSlug) {
        return null;
      }

      return {
        ...preview,
        slug: previewSlug,
        viewCount: preview.viewCount ?? 0
      };
    } catch {
      return null;
    }
  }

  private getPlaceholderImage(seed: number): string {
    return `https://picsum.photos/seed/alochito-related-${seed || 'placeholder'}/760/430`;
  }

  private buildEngagementCards(options: {
    excluded: Set<string>;
    limit: number;
    sortBy: 'latest' | 'trending';
  }): RelatedArticle[] {
    const current = this.article();
    if (!current) {
      return [];
    }

    const sourceItems = this.newsService
      .getAll()
      .filter((item) => this.newsService.isPubliclyVisible(item))
      .filter((item) => !options.excluded.has(this.normalizeSlug(item.slug || item.title)));

    const sortedItems = sourceItems.sort((left, right) => {
      if (options.sortBy === 'trending') {
        const trendDiff = (right.viewCount ?? 0) - (left.viewCount ?? 0);
        if (trendDiff !== 0) {
          return trendDiff;
        }
      }

      return this.getSortValue(right) - this.getSortValue(left);
    });

    return sortedItems
      .slice(0, options.limit)
      .map((item) => ({
        title: item.title,
        category: item.category,
        image: item.imageUrl || this.getPlaceholderImage(item.id),
        slug: this.cleanSlug(item.slug || item.title || `news-${item.id}`),
        time: formatNewsDate(item.publishDate || item.scheduledAt || item.createdAt, 'bn') || item.createdAt || '',
        readingTime: getReadingTime(item.content || item.subtitle || item.title, 'bn'),
        viewLabel: formatViewCount(item.viewCount ?? 0, 'bn')
      }));
  }

  private getSortValue(news: News): number {
    const source = news.publishDate || news.scheduledAt || news.createdAt;
    const parsed = Date.parse(source.replace(' ', 'T'));
    return Number.isNaN(parsed) ? 0 : parsed;
  }

  private normalizeSlug(value: string): string {
    return value
      .toLowerCase()
      .replace(/[^a-z0-9\u0980-\u09ff]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  private cleanSlug(value: string): string {
    return this.normalizeSlug(value);
  }

  private currentArticleUrl(article: ArticleView): string {
    const path = `/news/${article.slug}`;

    if (typeof window === 'undefined') {
      return path;
    }

    return `${window.location.origin}${path}`;
  }

  private copyToClipboard(value: string): void {
    if (navigator.clipboard?.writeText) {
      void navigator.clipboard.writeText(value).catch(() => this.copyWithTextarea(value));
      return;
    }

    this.copyWithTextarea(value);
  }

  private copyWithTextarea(value: string): void {
    const textarea = document.createElement('textarea');
    textarea.value = value;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';

    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
  }
}
