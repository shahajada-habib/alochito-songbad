import { inject, Injectable, signal } from '@angular/core';
import { AuthService } from '../../auth/auth.service';

const STORAGE_KEY = 'alochito_team';

export interface TeamMember {
  id: number;
  name: string;
  role: 'Editor' | 'Reporter' | 'Admin';
  email: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export type TeamMemberFormValue = Omit<TeamMember, 'id' | 'createdAt'>;

@Injectable({ providedIn: 'root' })
export class TeamService {
  private readonly auth = inject(AuthService);
  private readonly membersSignal = signal<TeamMember[]>(this.loadFromStorage() ?? this.createDefaultMembers());
  private nextId = this.calculateNextId(this.membersSignal());

  readonly members = this.membersSignal.asReadonly();

  getAll(): TeamMember[] {
    return this.membersSignal();
  }

  getById(id: number): TeamMember | undefined {
    return this.membersSignal().find((item) => item.id === id);
  }

  create(member: TeamMemberFormValue): TeamMember {
    this.ensureAdmin('create team member');
    const created: TeamMember = {
      ...member,
      id: this.nextId,
      createdAt: 'এইমাত্র'
    };

    this.nextId += 1;
    this.membersSignal.update((items) => [created, ...items]);
    this.saveToStorage();
    return created;
  }

  update(id: number, member: TeamMemberFormValue): TeamMember | undefined {
    this.ensureAdmin('update team member');
    let updatedMember: TeamMember | undefined;

    this.membersSignal.update((items) =>
      items.map((item) => {
        if (item.id !== id) {
          return item;
        }

        updatedMember = { ...item, ...member };
        return updatedMember;
      })
    );

    this.saveToStorage();
    return updatedMember;
  }

  delete(id: number): void {
    this.ensureAdmin('delete team member');
    this.membersSignal.update((items) => items.filter((item) => item.id !== id));
    this.saveToStorage();
  }

  private createDefaultMembers(): TeamMember[] {
    return [
      { id: 1, name: 'সাদিয়া রহমান', role: 'Editor', email: 'sadia@alochitosongbad.com', status: 'active', createdAt: 'আজ' },
      { id: 2, name: 'আরিফুল ইসলাম', role: 'Reporter', email: 'arif@alochitosongbad.com', status: 'active', createdAt: 'আজ' },
      { id: 3, name: 'নুসরাত জাহান', role: 'Admin', email: 'nusrat@alochitosongbad.com', status: 'active', createdAt: 'আজ' }
    ];
  }

  private loadFromStorage(): TeamMember[] | null {
    if (typeof localStorage === 'undefined') {
      return null;
    }

    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return null;
      }

      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as TeamMember[]) : null;
    } catch {
      return null;
    }
  }

  private saveToStorage(): void {
    if (typeof localStorage === 'undefined') {
      return;
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.membersSignal()));
    } catch {
      return;
    }
  }

  private calculateNextId(items: Array<{ id: number }>): number {
    return items.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  }

  private ensureAdmin(action: string): void {
    if (!this.auth.isAdmin()) {
      this.deny(`non-admin cannot ${action}`);
    }
  }

  private deny(message: string): never {
    console.warn(`Permission denied: ${message}`);
    throw new Error(`Permission denied: ${message}`);
  }
}
