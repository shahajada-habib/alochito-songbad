import { inject, Injectable, signal } from '@angular/core';
import { AuthService } from '../../auth/auth.service';

const STORAGE_KEY = 'alochito_comments';

export interface CommentItem {
  id: number;
  author: string;
  articleTitle: string;
  content: string;
  status: 'pending' | 'approved';
  createdAt: string;
}

@Injectable({ providedIn: 'root' })
export class CommentsService {
  private readonly auth = inject(AuthService);
  private readonly commentsSignal = signal<CommentItem[]>(this.loadFromStorage() ?? this.createDefaultComments());

  readonly comments = this.commentsSignal.asReadonly();

  approve(id: number): void {
    this.ensureCanModerate('approve comment');
    this.commentsSignal.update((items) =>
      items.map((item) => (item.id === id ? { ...item, status: 'approved' } : item))
    );
    this.saveToStorage();
  }

  delete(id: number): void {
    this.ensureCanModerate('delete comment');
    this.commentsSignal.update((items) => items.filter((item) => item.id !== id));
    this.saveToStorage();
  }

  private createDefaultComments(): CommentItem[] {
    return [
      {
        id: 1,
        author: 'Reader One',
        articleTitle: 'ঢাকার যানজট কমাতে নতুন প্রস্তাব',
        content: 'খবরটি বিস্তারিতভাবে ভালোভাবে লেখা হয়েছে।',
        status: 'pending',
        createdAt: '2026-04-30'
      },
      {
        id: 2,
        author: 'Reader Two',
        articleTitle: 'দলীয় প্রস্তুতি জোরদার করছে রাজনৈতিক দলগুলো',
        content: 'আরও তথ্যসূত্র যুক্ত করা দরকার।',
        status: 'approved',
        createdAt: '2026-04-30'
      }
    ];
  }

  private loadFromStorage(): CommentItem[] | null {
    if (typeof localStorage === 'undefined') {
      return null;
    }

    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return null;
      }

      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as CommentItem[]) : null;
    } catch {
      return null;
    }
  }

  private saveToStorage(): void {
    if (typeof localStorage === 'undefined') {
      return;
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.commentsSignal()));
    } catch {
      return;
    }
  }

  private ensureCanModerate(action: string): void {
    if (!this.auth.isAdmin() && !this.auth.isEditor()) {
      this.deny(`reporter cannot ${action}`);
    }
  }

  private deny(message: string): never {
    console.warn(`Permission denied: ${message}`);
    throw new Error(`Permission denied: ${message}`);
  }
}
