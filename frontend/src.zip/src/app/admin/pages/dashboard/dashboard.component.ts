import { Component, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';

import { AuthService } from '../../../auth/auth.service';
import { AdminTranslationService, TranslationKey } from '../../i18n/admin-translation.service';
import { NewsActivityAction, NewsService } from '../../services/news.service';
import { TeamService } from '../../services/team.service';

type DashboardStat = {
  labelKey: TranslationKey;
  count: number;
  trendKey: TranslationKey;
};

type DashboardActivity = {
  title: string;
  actionKey: TranslationKey;
  time: string;
};

type DashboardTask = {
  label: string;
  link: string;
  queryParams?: Record<string, string>;
};

type DashboardAction = {
  labelKey: TranslationKey;
  link: string;
  queryParams?: Record<string, string>;
};

const BANGLA_DIGITS = ['\u09e6', '\u09e7', '\u09e8', '\u09e9', '\u09ea', '\u09eb', '\u09ec', '\u09ed', '\u09ee', '\u09ef'];

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {
  private readonly authService = inject(AuthService);
  private readonly newsService = inject(NewsService);
  private readonly teamService = inject(TeamService);

  protected readonly stats = computed<DashboardStat[]>(() => {
    const news = this.newsService.getAll();

    return [
      {
        labelKey: 'published',
        count: news.filter((item) => item.status === 'published').length,
        trendKey: 'publishedTrend'
      },
      {
        labelKey: 'draft',
        count: news.filter((item) => item.status === 'draft').length,
        trendKey: 'draftTrend'
      },
      {
        labelKey: 'review',
        count: news.filter((item) => item.status === 'review').length,
        trendKey: 'reviewTrend'
      },
      {
        labelKey: 'totalTeamMembers',
        count: this.teamService.getAll().length,
        trendKey: 'teamTrend'
      }
    ];
  });

  protected readonly recentActivity = computed<DashboardActivity[]>(() =>
    this.newsService
      .getRecentActivity()
      .slice(0, 5)
      .map((item) => ({
        title: item.title,
        actionKey: this.activityActionKey(item.action),
        time: this.formatRelativeTime(item.timestamp)
      }))
  );

  protected readonly tasks = computed<DashboardTask[]>(() => {
    const news = this.newsService.getAll();
    const reviewCount = news.filter((item) => item.status === 'review').length;
    const draftCount = news.filter((item) => item.status === 'draft').length;

    return [
      {
        label: this.t('reviewArticles').replace('{count}', String(reviewCount)),
        link: '/admin/news',
        queryParams: { status: 'review' }
      },
      {
        label: this.t('completeDrafts').replace('{count}', String(draftCount)),
        link: '/admin/news',
        queryParams: { status: 'draft' }
      }
    ];
  });

  protected readonly quickActions = computed<DashboardAction[]>(() => {
    if (this.authService.isReporter()) {
      return [
        { labelKey: 'createNews', link: '/admin/news/create' },
        { labelKey: 'viewDrafts', link: '/admin/news', queryParams: { status: 'draft' } }
      ];
    }

    if (this.authService.isEditor()) {
      return [
        { labelKey: 'createNews', link: '/admin/news/create' },
        { labelKey: 'reviewNews', link: '/admin/news', queryParams: { status: 'review' } },
        { labelKey: 'publishQueue', link: '/admin/news', queryParams: { status: 'review' } }
      ];
    }

    return [
      { labelKey: 'createNews', link: '/admin/news/create' },
      { labelKey: 'manageTeam', link: '/admin/team' },
      { labelKey: 'manageCategories', link: '/admin/categories' }
    ];
  });

  constructor(protected readonly i18n: AdminTranslationService) {}

  protected t(key: TranslationKey): string {
    return this.i18n.t(key);
  }

  protected activityLabel(key: TranslationKey): string {
    return this.t(key);
  }

  private activityActionKey(action: NewsActivityAction): TranslationKey {
    const map: Record<NewsActivityAction, TranslationKey> = {
      created: 'activityCreated',
      updated: 'activityUpdated',
      published: 'activityPublished'
    };

    return map[action];
  }

  private formatRelativeTime(timestamp: number): string {
    const diffMs = Date.now() - timestamp;
    const minutes = Math.max(1, Math.floor(diffMs / 60000));

    if (minutes < 60) {
      return this.i18n.language() === 'bn'
        ? `${this.toBanglaDigits(minutes)} ${this.t('minutesAgo')}`
        : `${minutes} ${this.t('minutesAgo')}`;
    }

    const hours = Math.max(1, Math.floor(minutes / 60));
    if (hours < 24) {
      return this.i18n.language() === 'bn'
        ? `${this.toBanglaDigits(hours)} ${this.t('hoursAgo')}`
        : `${hours} ${this.t('hoursAgo')}`;
    }

    return this.t('justNow');
  }

  private toBanglaDigits(value: number): string {
    return String(value).replace(/\d/g, (digit) => BANGLA_DIGITS[Number(digit)]);
  }
}
